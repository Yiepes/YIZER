import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { styles } from './styles'; // ¡Ruta corregida!

const Header = ({ onMenuPress }) => (
  <View style={styles.header}>
    <TouchableOpacity onPress={onMenuPress} style={styles.menuIcon}>
      <Text style={styles.menuText}>☰</Text>
    </TouchableOpacity>
    <Text style={styles.headerTitle}>YIZER</Text>
    <View style={{ width: 30 }} />
  </View>
);

export default Header;
