import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import CustomButton from './CustomButton'; // Ruta corregida
import { styles } from './styles'; // Ruta corregida

const AuthSelectionScreen = ({ setScreen }) => {
  return (
    <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.screenTitle}>Bienvenido a YIZER</Text>
      <Text style={styles.subtitle}>Elige una opción para continuar.</Text>

      <CustomButton
        title="Iniciar Sesión"
        onPress={() => setScreen('login')}
        style={styles.authSelectionButton}
      />
      <CustomButton
        title="Registrarse"
        onPress={() => setScreen('register')}
        style={styles.authSelectionButton}
      />
      <CustomButton
        title="Recuperar Contraseña"
        onPress={() => setScreen('recovery')}
        style={styles.authSelectionButton}
      />
      <CustomButton
        title="Volver al Inicio"
        onPress={() => setScreen('home')}
        style={styles.backButton}
      />
    </ScrollView>
  );
};

export default AuthSelectionScreen;
