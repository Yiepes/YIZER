export const products = [
  {
    id: '1',
    name: 'Sudadera Grande',
    price: '250',
    image: 'https://placehold.co/300x300/B12A2A/FFFFFF?text=Sudadera',
    description: 'Sudadera de algodón suave y cómoda, ideal para cualquier ocasión. Disponible en varios colores y tallas.',
    availableColors: ['Rojo', 'Negro', 'Blanco', 'Gris'],
    availableSizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL']
  },
  {
    id: '2',
    name: 'Chaqueta Urbana',
    price: '320',
    image: 'https://placehold.co/300x300/B12A2A/FFFFFF?text=Chaqueta',
    description: 'Chaqueta moderna con diseño urbano, perfecta para el día a día. Fabricada con materiales de alta calidad.',
    availableColors: ['Azul', 'Verde', 'Negro'],
    availableSizes: ['S', 'M', 'L', 'XL']
  },
  {
    id: '3',
    name: 'Camiseta Básica',
    price: '180',
    image: 'https://placehold.co/300x300/B12A2A/FFFFFF?text=Camiseta',
    description: 'Camiseta de algodón 100%, ligera y transpirable. Un básico indispensable en tu armario.',
    availableColors: ['Blanco', 'Negro', 'Azul Claro', 'Rosa'],
    availableSizes: ['XS', 'S', 'M', 'L', 'XL']
  },
];

export const printPositions = ['Centro Frontal', 'Superior Izquierdo', 'Superior Derecho', 'Espalda Centro'];
export const printSizes = ['Pequeño', 'Mediano', 'Grande'];
