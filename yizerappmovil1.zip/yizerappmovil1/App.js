import React, { useState, useEffect } from 'react';
import { View, Modal, Alert, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

// Importaciones de componentes (rutas directas para Expo Snack)
import Header from './Header';
import SideMenu from './SideMenu';
import SuccessModal from './SuccessModal';
// CustomButton se importa directamente en los componentes que lo usan, no es necesario aquí si no se usa directamente en App.js

// Importaciones de pantallas (rutas directas para Expo Snack)
import HomeScreen from './HomeScreen';
import ProductScreen from './ProductScreen';
import PersonalizationScreen from './PersonalizationScreen';
import MyOrdersScreen from './MyOrdersScreen';
import AuthSelectionScreen from './AuthSelectionScreen';
import LoginScreen from './LoginScreen'; // ¡Verifica este nombre de archivo!
import RegisterScreen from './RegisterScreen';
import RecoveryScreen from './RecoveryScreen';

// Importaciones de constantes (rutas directas para Expo Snack)
import { products, printPositions, printSizes } from './data';
import { styles } from './styles';

const App = () => {
  const [screen, setScreen] = useState('home');
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [currentCartItems, setCurrentCartItems] = useState([]);
  const [pastOrders, setPastOrders] = useState([]);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const [selectedBaseProductForCustomization, setSelectedBaseProductForCustomization] = useState(null);
  const [customizationOptions, setCustomizationOptions] = useState({
    size: 'M',
    color: 'Blanco',
    quantity: 1,
    printPosition: 'Centro Frontal',
    printSize: 'Mediano',
    printImage: 'https://placehold.co/100x100/FFD700/000?text=Estampado'
  });

  useEffect(() => {
    if (selectedBaseProductForCustomization) {
      setCustomizationOptions({
        size: selectedBaseProductForCustomization.availableSizes[0] || 'M',
        color: selectedBaseProductForCustomization.availableColors[0] || 'Blanco',
        quantity: 1,
        printPosition: printPositions[0],
        printSize: printSizes[0],
        printImage: 'https://placehold.co/100x100/FFD700/000?text=Estampado'
      });
    }
  }, [selectedBaseProductForCustomization]);

  const addToCart = (productToAdd) => {
    setCurrentCartItems((prevItems) => {
      const existingItemIndex = prevItems.findIndex(
        (item) =>
          item.id === productToAdd.id &&
          item.customization && productToAdd.customization &&
          item.customization.size === productToAdd.customization.size &&
          item.customization.color === productToAdd.customization.color &&
          item.customization.printPosition === productToAdd.customization.printPosition &&
          item.customization.printSize === productToAdd.customization.printSize
      );

      if (existingItemIndex > -1) {
        const updatedItems = [...prevItems];
        updatedItems[existingItemIndex].quantity += productToAdd.quantity;
        return updatedItems;
      }
      return [...prevItems, productToAdd];
    });
    setScreen('myOrders');
  };

  const removeFromCart = (itemToRemove) => {
    setCurrentCartItems((prevItems) =>
      prevItems.filter(
        (item) =>
          !(
            item.id === itemToRemove.id &&
            item.customization && itemToRemove.customization &&
            item.customization.size === itemToRemove.customization.size &&
            item.customization.color === itemToRemove.customization.color &&
            item.customization.printPosition === itemToRemove.customization.printPosition &&
            item.customization.printSize === itemToRemove.customization.printSize
          )
      )
    );
  };

  const getTotalCartPrice = () => {
    return currentCartItems.reduce((total, item) => total + parseFloat(item.price) * item.quantity, 0);
  };

  const handlePurchase = () => {
    if (currentCartItems.length === 0) {
      Alert.alert("Carrito Vacío", "No hay productos en el carrito para confirmar la compra.");
      return;
    }

    const newOrder = {
      orderId: `ORD-${Date.now()}`,
      items: [...currentCartItems],
      orderDate: new Date().toLocaleDateString('es-ES'),
      status: 'Confirmado',
      estimatedDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString('es-ES'),
      totalPrice: getTotalCartPrice(),
    };

    setPastOrders((prevOrders) => [...prevOrders, newOrder]);
    setCurrentCartItems([]);
    setShowSuccessModal(true);
  };

  const handleCloseSuccessModal = () => {
    setShowSuccessModal(false);
    setScreen('myOrders');
  };

  const updateCustomization = (key, value) => {
    setCustomizationOptions((prev) => ({ ...prev, [key]: value }));
  };

  const handleConfirmCustomization = () => {
    if (!selectedBaseProductForCustomization) return;

    const customizedProduct = {
      ...selectedBaseProductForCustomization,
      id: `${selectedBaseProductForCustomization.id}-${Date.now()}`,
      quantity: customizationOptions.quantity,
      customization: { ...customizationOptions },
    };
    addToCart(customizedProduct);
    setSelectedBaseProductForCustomization(null);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <Header onMenuPress={() => setIsMenuOpen(true)} />

      {screen === 'home' && (
        <HomeScreen
          products={products}
          setScreen={setScreen}
          setSelectedProduct={setSelectedProduct}
        />
      )}
      {screen === 'product' && (
        <ProductScreen
          selectedProduct={selectedProduct}
          setScreen={setScreen}
          addToCart={addToCart}
        />
      )}
      {screen === 'myOrders' && (
        <MyOrdersScreen
          currentCartItems={currentCartItems}
          pastOrders={pastOrders}
          removeFromCart={removeFromCart}
          getTotalCartPrice={getTotalCartPrice}
          handlePurchase={handlePurchase}
          setScreen={setScreen}
        />
      )}
      {screen === 'personalization' && (
        <PersonalizationScreen
          products={products}
          selectedBaseProductForCustomization={selectedBaseProductForCustomization}
          setSelectedBaseProductForCustomization={setSelectedBaseProductForCustomization}
          customizationOptions={customizationOptions}
          updateCustomization={updateCustomization}
          handleConfirmCustomization={handleConfirmCustomization}
          printPositions={printPositions}
          printSizes={printSizes}
          setScreen={setScreen}
        />
      )}
      {screen === 'authSelection' && (
        <AuthSelectionScreen
          setScreen={setScreen}
        />
      )}
      {screen === 'login' && (
        <LoginScreen
          setScreen={setScreen}
        />
      )}
      {screen === 'register' && (
        <RegisterScreen
          setScreen={setScreen}
        />
      )}
      {screen === 'recovery' && (
        <RecoveryScreen
          setScreen={setScreen}
        />
      )}

      <SideMenu
        isMenuOpen={isMenuOpen}
        setIsMenuOpen={setIsMenuOpen}
        setScreen={setScreen}
      />

      <SuccessModal
        showSuccessModal={showSuccessModal}
        handleCloseSuccessModal={handleCloseSuccessModal}
      />
    </SafeAreaView>
  );
};

export default App;
