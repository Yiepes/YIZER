import React from 'react';
import { View, Text, ScrollView, Image, TouchableOpacity } from 'react-native';
import CustomButton from './CustomButton'; // Ruta corregida
import { styles } from './styles'; // Ruta corregida

const MyOrdersScreen = ({
  currentCartItems,
  pastOrders,
  removeFromCart,
  getTotalCartPrice,
  handlePurchase,
  setScreen,
}) => {
  return (
    <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.screenTitle}>Mi Compra</Text>

      {/* Current Cart Items (Pending Purchase) */}
      {currentCartItems.length > 0 && (
        <View style={styles.currentCartSection}>
          <Text style={styles.sectionTitle}>Productos Pendientes de Confirmar:</Text>
          {currentCartItems.map((item, index) => (
            <View key={`${item.id}-${index}-current`} style={styles.cartItem}>
              <Image source={{ uri: item.image }} style={styles.cartItemImage} />
              <View style={styles.cartItemDetails}>
                <Text style={styles.cartItemName}>{item.name}</Text>
                {item.customization && (
                  <View>
                    <Text style={styles.cartItemCustomization}>Talla: {item.customization.size}</Text>
                    <Text style={styles.cartItemCustomization}>Color: {item.customization.color}</Text>
                    <Text style={styles.cartItemCustomization}>Estampado: {item.customization.printPosition} ({item.customization.printSize})</Text>
                  </View>
                )}
                <Text style={styles.cartItemPrice}>${item.price} x {item.quantity}</Text>
                <Text style={styles.cartItemPrice}>Total: ${parseFloat(item.price) * item.quantity}</Text>
              </View>
              <CustomButton
                title="Eliminar"
                onPress={() => removeFromCart(item)}
                style={styles.removeButton}
                textStyle={styles.removeButtonText}
              />
            </View> // <-- ¡CORREGIDO! Antes estaba </TouchableOpacity>
          ))}
          <Text style={styles.totalPrice}>Total Pendiente: ${getTotalCartPrice()}</Text>
          <CustomButton
            title="Confirmar Compra"
            onPress={handlePurchase}
            style={styles.confirmPurchaseButton}
          />
        </View>
      )}

      {/* Past Orders (Tracking) */}
      <Text style={styles.sectionTitle}>Mis Pedidos Anteriores:</Text>
      {pastOrders.length === 0 ? (
        <Text style={styles.emptyCartText}>No has realizado ningún pedido aún.</Text>
      ) : (
        pastOrders.map((order, orderIndex) => (
          <View key={order.orderId} style={styles.orderCard}>
            <Text style={styles.orderId}>Pedido #{order.orderId}</Text>
            <Text style={styles.orderInfo}>Fecha del Pedido: {order.orderDate}</Text>
            <Text style={styles.orderInfo}>Estado: <Text style={styles.orderStatus}>{order.status}</Text></Text>
            <Text style={styles.orderInfo}>Entrega Estimada: {order.estimatedDelivery}</Text>
            <Text style={styles.orderTotal}>Total: ${order.totalPrice}</Text>
            <View style={styles.orderItemsContainer}>
              {order.items.map((item, itemIndex) => (
                <View key={`${item.id}-${itemIndex}-order-item`} style={styles.orderItem}>
                  <Image source={{ uri: item.image }} style={styles.orderItemImage} />
                  <View style={styles.orderItemDetails}>
                    <Text style={styles.orderItemName}>{item.name}</Text>
                    {item.customization && (
                      <View>
                        <Text style={styles.orderItemCustomization}>Talla: {item.customization.size}</Text>
                        <Text style={styles.orderItemCustomization}>Color: {item.customization.color}</Text>
                        <Text style={styles.orderItemCustomization}>Estampado: {item.customization.printPosition} ({item.customization.printSize})</Text>
                      </View>
                    )}
                    <Text style={styles.orderItemPrice}>${item.price} x {item.quantity}</Text>
                  </View>
                </View> // <-- ¡CORREGIDO! Antes estaba </TouchableOpacity>
              ))}
            </View>
          </View>
        ))
      )}
      <CustomButton
        title="Seguir Comprando"
        onPress={() => setScreen('home')}
        style={styles.backButton}
      />
    </ScrollView>
  );
};

export default MyOrdersScreen;
