import React from 'react';
import { Modal, View, Text, Image } from 'react-native';
import CustomButton from './CustomButton'; // Ruta corregida
import { styles } from './styles'; // Ruta corregida

const SuccessModal = ({ showSuccessModal, handleCloseSuccessModal }) => {
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={showSuccessModal}
      onRequestClose={handleCloseSuccessModal}
    >
      <View style={styles.centeredView}>
        <View style={styles.modalView}>
          <Text style={styles.modalTitle}>¡Compra exitosa!</Text>
          <Text style={styles.modalText}>Tu pedido ha sido procesado.</Text>
          <Image
            source={{ uri: 'https://placehold.co/100x100/B12A2A/FFFFFF?text=✓' }}
            style={styles.successImage}
          />
          <CustomButton
            title="Aceptar"
            onPress={handleCloseSuccessModal}
            style={styles.modalButton}
          />
        </View>
      </View>
    </Modal>
  );
};

export default SuccessModal;
