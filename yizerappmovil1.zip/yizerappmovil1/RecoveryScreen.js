import React from 'react';
import { View, Text, ScrollView, TextInput, Alert } from 'react-native';
import CustomButton from './CustomButton'; // Ruta corregida
import { styles } from './styles'; // Ruta corregida

const RecoveryScreen = ({ setScreen }) => {
  return (
    <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.screenTitle}>Recuperar Contraseña</Text>
      <TextInput
        style={styles.input}
        placeholder="Correo electrónico"
        keyboardType="email-address"
        autoCapitalize="none"
        placeholderTextColor="#aaa"
      />
      <CustomButton
        title="Enviar Contraseña"
        onPress={() => {
          Alert.alert("Recuperación", "Se ha enviado un enlace de recuperación a tu correo.");
          setScreen('login');
        }}
        style={styles.authButton}
      />
      <CustomButton
        title="Volver"
        onPress={() => setScreen('authSelection')}
        style={styles.backButton}
      />
    </ScrollView>
  );
};

export default RecoveryScreen;
