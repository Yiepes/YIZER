import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image, Alert } from 'react-native';
import CustomButton from './CustomButton'; // Ruta corregida
import { styles } from './styles'; // Ruta corregida

const PersonalizationScreen = ({
  products,
  selectedBaseProductForCustomization,
  setSelectedBaseProductForCustomization,
  customizationOptions,
  updateCustomization,
  handleConfirmCustomization,
  printPositions,
  printSizes,
  setScreen,
}) => {
  const printStyle = {};
  const printSizeMap = {
    'Pequeño': { width: 50, height: 50 },
    'Mediano': { width: 80, height: 80 },
    'Grande': { width: 120, height: 120 },
  };
  const currentPrintSize = printSizeMap[customizationOptions.printSize] || printSizeMap['Mediano'];

  switch (customizationOptions.printPosition) {
    case 'Centro Frontal':
      printStyle.alignSelf = 'center';
      printStyle.top = '40%';
      break;
    case 'Superior Izquierdo':
      printStyle.alignSelf = 'flex-start';
      printStyle.top = '10%';
      printStyle.left = '10%';
      break;
    case 'Superior Derecho':
      printStyle.alignSelf = 'flex-end';
      printStyle.top = '10%';
      printStyle.right = '10%';
      break;
    case 'Espalda Centro':
      printStyle.alignSelf = 'center';
      printStyle.top = '40%';
      break;
    default:
      printStyle.alignSelf = 'center';
      printStyle.top = '40%';
  }

  const getProductImageColor = (colorName) => {
    const colorMap = {
      'Rojo': 'B12A2A',
      'Negro': '000000',
      'Blanco': 'FFFFFF',
      'Gris': '808080',
      'Azul': '0000FF',
      'Verde': '008000',
      'Azul Claro': 'ADD8E6',
      'Rosa': 'FFC0CB',
    };
    const hexColor = colorMap[colorName] || 'B12A2A';
    const productNameForPlaceholder = selectedBaseProductForCustomization ? selectedBaseProductForCustomization.name.split(' ')[0] : 'Producto';
    return `https://placehold.co/300x300/${hexColor}/FFFFFF?text=${productNameForPlaceholder}`;
  };

  if (!selectedBaseProductForCustomization) {
    return (
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.screenTitle}>Elige un Producto para Personalizar</Text>
        <View style={styles.productGrid}>
          {products.map((product) => (
            <TouchableOpacity
              key={product.id}
              style={styles.productCard}
              onPress={() => setSelectedBaseProductForCustomization(product)}
            >
              <Image source={{ uri: product.image }} style={styles.productImage} />
              <Text style={styles.productName}>{product.name}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <CustomButton
          title="Volver al Inicio"
          onPress={() => setScreen('home')}
          style={styles.backButton}
        />
      </ScrollView>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.screenTitle}>Personalizar {selectedBaseProductForCustomization.name}</Text>

      <View style={styles.previewContainer}>
        <Image
          source={{ uri: getProductImageColor(customizationOptions.color) }}
          style={styles.previewProductImage}
        />
        <Image
          source={{ uri: customizationOptions.printImage }}
          style={[styles.previewPrintImage, printStyle, currentPrintSize]}
        />
      </View>

      <View style={styles.customizationOptionsContainer}>
        <Text style={styles.optionTitle}>Talla:</Text>
        <View style={styles.optionRow}>
          {selectedBaseProductForCustomization.availableSizes.map((size) => (
            <CustomButton
              key={size}
              title={size}
              onPress={() => updateCustomization('size', size)}
              style={[
                styles.optionButton,
                customizationOptions.size === size && styles.optionButtonSelected,
              ]}
              textStyle={styles.optionButtonText}
            />
          ))}
        </View>

        <Text style={styles.optionTitle}>Color:</Text>
        <View style={styles.optionRow}>
          {selectedBaseProductForCustomization.availableColors.map((color) => (
            <TouchableOpacity
              key={color}
              style={[
                styles.colorSwatch,
                { backgroundColor: color.toLowerCase().replace(' ', '') },
                customizationOptions.color === color && styles.colorSwatchSelected,
              ]}
              onPress={() => updateCustomization('color', color)}
            />
          ))}
        </View>

        <Text style={styles.optionTitle}>Cantidad:</Text>
        <View style={styles.quantityContainer}>
          <CustomButton
            title="-"
            onPress={() => updateCustomization('quantity', Math.max(1, customizationOptions.quantity - 1))}
            style={styles.quantityButton}
            textStyle={styles.quantityButtonText}
          />
          <Text style={styles.quantityText}>{customizationOptions.quantity}</Text>
          <CustomButton
            title="+"
            onPress={() => updateCustomization('quantity', customizationOptions.quantity + 1)}
            style={styles.quantityButton}
            textStyle={styles.quantityButtonText}
          />
        </View>

        <Text style={styles.optionTitle}>Posición del Estampado:</Text>
        <View style={styles.optionRow}>
          {printPositions.map((position) => (
            <CustomButton
              key={position}
              title={position}
              onPress={() => updateCustomization('printPosition', position)}
              style={[
                styles.optionButton,
                customizationOptions.printPosition === position && styles.optionButtonSelected,
              ]}
              textStyle={styles.optionButtonText}
            />
          ))}
        </View>

        <Text style={styles.optionTitle}>Tamaño del Estampado:</Text>
        <View style={styles.optionRow}>
          {printSizes.map((size) => (
            <CustomButton
              key={size}
              title={size}
              onPress={() => updateCustomization('printSize', size)}
              style={[
                styles.optionButton,
                customizationOptions.printSize === size && styles.optionButtonSelected,
              ]}
              textStyle={styles.optionButtonText}
            />
          ))}
        </View>
      </View>

      <CustomButton
        title="Confirmar Producto"
        onPress={handleConfirmCustomization}
        style={styles.confirmCustomizationButton}
      />
      <CustomButton
        title="Modificar Diseño"
        onPress={() => {
          Alert.alert("Modificar Diseño", "Puedes ajustar las opciones de personalización arriba.");
        }}
        style={styles.modifyDesignButton}
      />
      <CustomButton
        title="Volver a Elegir Producto"
        onPress={() => setSelectedBaseProductForCustomization(null)}
        style={styles.backButton}
      />
    </ScrollView>
  );
};

export default PersonalizationScreen;
