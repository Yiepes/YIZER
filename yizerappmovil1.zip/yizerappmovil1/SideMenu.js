import React from 'react';
import { Modal, View, Text, TouchableOpacity, Dimensions } from 'react-native';
import { styles } from './styles'; // Ruta corregida

const { width } = Dimensions.get('window');

const SideMenu = ({ isMenuOpen, setIsMenuOpen, setScreen }) => {
  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={isMenuOpen}
      onRequestClose={() => setIsMenuOpen(false)}
    >
      <TouchableOpacity
        style={styles.menuOverlay}
        activeOpacity={1}
        onPressOut={() => setIsMenuOpen(false)}
      >
        <View style={styles.menuContainer}>
          <TouchableOpacity style={styles.menuItem} onPress={() => { setScreen('home'); setIsMenuOpen(false); }}>
            <Text style={styles.menuItemText}>INICIO</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuItem} onPress={() => { setScreen('myOrders'); setIsMenuOpen(false); }}>
            <Text style={styles.menuItemText}>MI COMPRA</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuItem} onPress={() => { setScreen('personalization'); setIsMenuOpen(false); }}>
            <Text style={styles.menuItemText}>PERSONALIZACIONES</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuItem} onPress={() => { setScreen('authSelection'); setIsMenuOpen(false); }}>
            <Text style={styles.menuItemText}>AUTENTICACIÓN</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    </Modal>
  );
};

export default SideMenu;
