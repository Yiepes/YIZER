import React from 'react';
import { View, Text, ScrollView, Image } from 'react-native';
import CustomButton from './CustomButton'; // Ruta corregida
import { styles } from './styles'; // Ruta corregida

const ProductScreen = ({ selectedProduct, setScreen, addToCart }) => {
  return (
    <ScrollView contentContainerStyle={styles.scrollContent}>
      {selectedProduct && (
        <View style={styles.productDetailContainer}>
          <Image source={{ uri: selectedProduct.image }} style={styles.productDetailImage} />
          <Text style={styles.productDetailName}>{selectedProduct.name}</Text>
          <Text style={styles.productDetailPrice}>${selectedProduct.price}</Text>
          <Text style={styles.productDetailDescription}>{selectedProduct.description}</Text>

          <CustomButton
            title="Añadir al Carrito"
            onPress={() => {
              addToCart({ ...selectedProduct, quantity: 1, customization: null });
            }}
            style={styles.addToCartButton}
          />
          <CustomButton
            title="Volver"
            onPress={() => setScreen('home')}
            style={styles.backButton}
          />
        </View>
      )}
    </ScrollView>
  );
};

export default ProductScreen;
