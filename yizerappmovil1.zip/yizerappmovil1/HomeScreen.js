import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import CustomButton from './CustomButton'; // Ruta corregida
import { styles } from './styles'; // Ruta corregida

const HomeScreen = ({ products, setScreen, setSelectedProduct }) => {
  return (
    <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.title}>YIZER</Text>
      <Text style={styles.subtitle}>Personaliza tu mundo con estilo.</Text>

      <CustomButton
        title="Iniciar Sesión"
        onPress={() => setScreen('authSelection')}
        style={styles.heroButton}
      />
      <CustomButton
        title="Registrarse"
        onPress={() => setScreen('authSelection')}
        style={styles.heroButton}
      />

      <View style={styles.productGrid}>
        {products.map((product) => (
          <TouchableOpacity
            key={product.id}
            style={styles.productCard}
            onPress={() => {
              setSelectedProduct(product);
              setScreen('product');
            }}
          >
            <Image source={{ uri: product.image }} style={styles.productImage} />
            <Text style={styles.productName}>{product.name}</Text>
            <Text style={styles.productPrice}>${product.price}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
};

export default HomeScreen;
