import React from 'react';
import { TouchableOpacity, Text } from 'react-native';
import { styles } from './styles'; // ¡Ruta corregida!

const CustomButton = ({ title, onPress, style, textStyle, disabled = false }) => (
  <TouchableOpacity
    style={[styles.button, style, disabled && styles.buttonDisabled]}
    onPress={onPress}
    disabled={disabled}
    activeOpacity={0.7}
  >
    <Text style={[styles.buttonText, textStyle]}>{title}</Text>
  </TouchableOpacity>
);

export default CustomButton;
