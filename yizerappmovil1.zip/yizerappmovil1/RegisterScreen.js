import React from 'react';
import { View, Text, ScrollView, TextInput, Alert } from 'react-native';
import CustomButton from './CustomButton'; // Ruta corregida
import { styles } from './styles'; // Ruta corregida

const RegisterScreen = ({ setScreen }) => {
  return (
    <ScrollView contentContainerStyle={styles.scrollContent}>
      <Text style={styles.screenTitle}>Registrarse</Text>
      <TextInput
        style={styles.input}
        placeholder="Nombre de usuario"
        placeholderTextColor="#aaa"
      />
      <TextInput
        style={styles.input}
        placeholder="Correo electrónico"
        keyboardType="email-address"
        autoCapitalize="none"
        placeholderTextColor="#aaa"
      />
      <TextInput
        style={styles.input}
        placeholder="Contraseña"
        secureTextEntry
        placeholderTextColor="#aaa"
      />
      <TextInput
        style={styles.input}
        placeholder="Confirmar Contraseña"
        secureTextEntry
        placeholderTextColor="#aaa"
      />
      <CustomButton
        title="Registrar"
        onPress={() => {
          Alert.alert("Registro", "Funcionalidad de registro simulada.");
          setScreen('home');
        }}
        style={styles.authButton}
      />
      <CustomButton
        title="Volver"
        onPress={() => setScreen('authSelection')}
        style={styles.backButton}
      />
    </ScrollView>
  );
};

export default RegisterScreen;
